#ifndef I_ROBOT_CONTROLLER_H
#define I_ROBOT_CONTROLLER_H
#include "WPILib.h"

class CRobot;

class IRobotController
{
public:
	
	IRobotController()
	{
		m_parentBot = 0;
	}
	
	virtual ~IRobotController(){}
	
	virtual void update(){}
	
	CRobot* m_parentBot;
	
protected:
	
	Joystick* m_leftStick;
	Joystick* m_rightStick;
};

#endif
