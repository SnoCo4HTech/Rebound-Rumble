#ifndef C_TELEOP_CONTROLLER_H
#define C_TELEOP_CONTROLLER_H
#include "IRobotController.h"

class CTeleopController : public IRobotController
{
public:
	
	CTeleopController(Joystick* leftStick, Joystick* rightStick);
	~CTeleopController();
	
	virtual void update();
	
private:
	
	void updateSteering();
	
	void updateArmControl();
	
	void updateChuteControl();
	
	void doReload();
	
	Joystick* m_leftStick;
	Joystick* m_rightStick;
	
	Gyro* m_gyro;
	
	ADXL345_I2C* m_accelerometer;
	
	float m_speedCoeff;
};

#endif
