#include "CPistonControl.h"

const unsigned int DOWN_PIN = 2;
const unsigned int UP_PIN = 1;

const unsigned int COMPRESSOR_INPUT = 1;
const unsigned int COMPRESSOR_SPIKE = 1;

CPistonControl::CPistonControl()
{
	//Piston up/down
	m_upCtrl.reset(new Solenoid(UP_PIN));
	m_upCtrl->Set(false);
	m_downCtrl.reset(new Solenoid(DOWN_PIN));
	m_downCtrl->Set(false);
	
	//Air compressor
	m_compressor.reset(new Relay(COMPRESSOR_SPIKE, Relay::kForwardOnly));
	m_compressor->Set(Relay::kOff);
	
	//Air compressor pressure sensor
	m_compressorInput.reset(new DigitalInput(COMPRESSOR_INPUT));
}

void CPistonControl::setPiston(bool up)
{
	if ( up )
	{
		m_upCtrl->Set(true);
		m_downCtrl->Set(false);
	}
	else
	{
		m_upCtrl->Set(false);
		m_downCtrl->Set(true);
	}
}

void CPistonControl::update()
{	
	//Update compressor
	if ( m_compressorInput->Get() == 0 )
	{
		m_compressor->Set(Relay::kForward);
	}
	else
	{
		m_compressor->Set(Relay::kOff);
	}
}
