#include "CTeleopController.h"
#include "CRobot.h"

//360 button mapping
//A: 0
//B: 1
//X: 2
//Y: 3
//L: 4
//R: 5
//Back: 6
//Start: 7
//Left stick down: 8
//Right stick down: 9

const unsigned int ACCELEROMETER_CHANNEL = 1;
const unsigned int GYROSCOPE_CHANNEL = 8;

const float THRESHOLD = 0.35f;

CTeleopController::CTeleopController(Joystick* leftStick, Joystick* rightStick)
	:IRobotController(), m_speedCoeff(1.0f)
{
	m_leftStick = leftStick;
	m_rightStick = rightStick;
	
	//m_gyro = new Gyro(GYROSCOPE_CHANNEL);
	m_accelerometer = new ADXL345_I2C(ACCELEROMETER_CHANNEL);
}

CTeleopController::~CTeleopController()
{
	delete m_accelerometer;
	//delete m_gyro;
}

void CTeleopController::update()
{
	/*std::cout << "X: " << m_accelerometer->GetAcceleration(ADXL345_I2C::kAxis_X)
					<< " Y: "<< m_accelerometer->GetAcceleration(ADXL345_I2C::kAxis_Y)
					<< " Z: "<< m_accelerometer->GetAcceleration(ADXL345_I2C::kAxis_Z) << "\n";*/
	
	if ( m_leftStick->GetRawButton(7) )
		m_speedCoeff = 0.65f;
	else
		m_speedCoeff = 1.0f;
	
	updateArmControl();

	updateSteering();
	
	updateChuteControl();
	
	if ( m_rightStick->GetRawButton(11) && m_rightStick->GetRawButton(10) )
	{
		doReload();
	}
}

void CTeleopController::updateChuteControl()
{
	/*static bool flag = true;
		
	if ( m_rightStick->GetRawButton(2) )
	{
		if ( m_rightStick->GetRawButton(3) )
		{
			m_parentBot->setLaunchMotor(0.5f);
		}
		else
		{
			m_parentBot->setLaunchMotor(0.0f);
		}
		
		if ( m_rightStick->GetTrigger() )
		{
			if ( flag )
			{
				flag = false;
				
				if ( m_parentBot->getChuteState() == ECS_OPENED )
				{
					m_parentBot->setChuteState(ECS_CLOSED);
				}
				else
				{
					m_parentBot->setChuteState(ECS_OPENED);
				}
			}
		}
	}
	else
	{
		flag = true;
	}*/
	
	if ( m_rightStick->GetTrigger()/*GetRawButton*/ )
	{
		if ( m_rightStick->GetRawButton(2) )
		{
			m_parentBot->setChuteState(ECS_OPENED);
			m_parentBot->setLaunchMotor(0.5f);
		}
	}
	else
	{
		m_parentBot->setChuteState(ECS_CLOSED);
		m_parentBot->setLaunchMotor(0.0f);
	}
}

void CTeleopController::doReload()
{
	m_parentBot->setChuteState(ECS_OPENED);
	m_parentBot->setLaunchMotor(-0.2f);
	sleep(2);
	m_parentBot->setLaunchMotor(ECS_CLOSED);
	m_parentBot->setLaunchMotor(0.0f);
}

void CTeleopController::updateArmControl()
{
	float mul = 1.0f;
	
	if ( m_rightStick->GetRawButton(6) )
	{
		mul = 0.5f;
	}
	
	if ( m_rightStick->GetY() > 0.0f )
		mul = 0.3f;
	
	m_parentBot->moveArm(m_rightStick->GetY()*mul);
}

void CTeleopController::updateSteering()
{	
	float joyX = m_leftStick->GetX();
	float joyY = m_leftStick->GetY();
	
	float speedCoeff = ((m_leftStick->GetThrottle()-1.0f)*0.5f)+0.4f;
	
	float lSpeed = 0.0f;
	float rSpeed = 0.0f;
	
	if ( m_leftStick->GetTrigger() )
	{
		joyX *= 0.8f;
		
		lSpeed = -joyX;
		rSpeed = joyX;
	}
	else
	{				
		lSpeed = joyY;
		rSpeed = joyY;
		
		if ( joyX < -THRESHOLD )
		{
			joyX *= -1.0f;
			
			lSpeed *= joyX*0.25f;
		}
		else if ( joyX > THRESHOLD )
		{
			rSpeed *= joyX*0.25f;
		}
	}
	
	m_parentBot->driveLeftMotor(lSpeed*speedCoeff*m_speedCoeff);
	m_parentBot->driveRightMotor(rSpeed*speedCoeff*m_speedCoeff);
}
