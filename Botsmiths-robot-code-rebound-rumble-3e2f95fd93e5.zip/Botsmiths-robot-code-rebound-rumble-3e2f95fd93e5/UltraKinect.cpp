#include "UltraKinect.h"
#include <cmath>

UltraKinect::UltraKinect()
{
	m_kinect = Kinect::GetInstance();
	
	m_headStartY = m_kinect->GetSkeleton().GetHead().y;
}

void UltraKinect::update()
{
	Skeleton skel = m_kinect->GetSkeleton();
	
	static bool firstTime = true;
	if ( firstTime )
	{
		//Set the joint positions first
		for (int i=0; i<Skeleton::JointCount; ++i)
		{
			m_jointLastPositions[i] = skel.GetJointValue((Skeleton::JointTypes)i);
		}
		
		firstTime = false;
	}
	
	//Get the current positions
	for (int i=0; i<Skeleton::JointCount; ++i)
	{
		Skeleton::Joint currentJointPos = skel.GetJointValue((Skeleton::JointTypes)i);
		
		m_jointDeltaPositions[i] = subtractJoints(currentJointPos, m_jointLastPositions[i]);
		
		m_jointLastPositions[i] = currentJointPos;
	}
}

Skeleton::Joint UltraKinect::subtractJoints(Skeleton::Joint& j, Skeleton::Joint& k)
{
	Skeleton::Joint ret;
	
	ret.x = j.x - k.x;
	ret.y = j.y - k.y;
	ret.z = j.z - k.z;
	
	return ret;
}

bool UltraKinect::isValid()
{
	return m_kinect->GetNumberOfPlayers() > 0;
}

Skeleton::Joint UltraKinect::getDeltaPosition(Skeleton::JointTypes type)
{
	return multiplyJoints(m_jointDeltaPositions[type], 50.0f);
}

Skeleton::Joint UltraKinect::multiplyJoints(Skeleton::Joint& j, float f)
{
	Skeleton::Joint ret;
	ret.x = j.x * f;
	ret.y = j.y * f;
	ret.z = j.z * f;
	
	return ret;
}

Skeleton::Joint UltraKinect::getJointPosition(Skeleton::JointTypes type)
{
	Skeleton skel = m_kinect->GetSkeleton();
	Skeleton::Joint j = skel.GetJointValue(type);
	
	return j;
}

bool UltraKinect::isJointOnSide(E_JOINT_SIDE side, Skeleton::JointTypes type)
{
	Skeleton skel = m_kinect->GetSkeleton();
	
	if ( side == EJS_RIGHT )
		return skel.GetJointValue(type).x > skel.GetJointValue(Skeleton::HipCenter).x;
	else
		return skel.GetJointValue(type).x < skel.GetJointValue(Skeleton::HipCenter).x;
}

bool UltraKinect::isUpSignal(E_JOINT_SIDE side)
{
	Skeleton skel = m_kinect->GetSkeleton();
	
	if ( side == EJS_RIGHT )
	{
		Skeleton::Joint shoulder = skel.GetShoulderRight();
		Skeleton::Joint elbow = skel.GetElbowRight();
		Skeleton::Joint hand = skel.GetHandRight();
		
		if ( ((shoulder.x < elbow.x) && (elbow.y < hand.y)) && elbow.y > shoulder.y-0.1f )
			return true;
	}
	else
	{
		Skeleton::Joint shoulder = skel.GetShoulderLeft();
		Skeleton::Joint elbow = skel.GetElbowLeft();
		Skeleton::Joint hand = skel.GetHandLeft();
		
		if ( ((shoulder.x > elbow.x) && (elbow.y < hand.y)) && elbow.y > shoulder.y-0.1f )
			return true;
	}
	
	return false;
}

bool UltraKinect::isDownSignal(E_JOINT_SIDE side)
{
	Skeleton skel = m_kinect->GetSkeleton();
	
	if ( side == EJS_RIGHT )
	{
		Skeleton::Joint shoulder = skel.GetShoulderRight();
		Skeleton::Joint elbow = skel.GetElbowRight();
		Skeleton::Joint hand = skel.GetHandRight();
		
		if ( ((shoulder.x < elbow.x) && (elbow.y > hand.y)) && hand.y > skel.GetHipCenter().y-0.2f )
			return true;
	}
	else
	{
		Skeleton::Joint shoulder = skel.GetShoulderLeft();
		Skeleton::Joint elbow = skel.GetElbowLeft();
		Skeleton::Joint hand = skel.GetHandLeft();
		
		if ( ((shoulder.x > elbow.x) && (elbow.y < hand.y)) && hand.y > skel.GetHipCenter().y-0.2f )
			return true;
	}
	
	return false;
}

bool UltraKinect::isCrouching()
{	
	Skeleton skel = m_kinect->GetSkeleton();
	
	return skel.GetHead().y < m_headStartY-0.2f;
}

float UltraKinect::getJointAngles(Skeleton::JointTypes ja, Skeleton::JointTypes jb)
{
	Skeleton skel = m_kinect->GetSkeleton();
	Skeleton::Joint a = skel.GetJointValue(ja);
	Skeleton::Joint b = skel.GetJointValue(jb);
	
	//Note: replace cosh with arcos
	float totalTop = ( (-b.x)*(a.x)+(a.x*a.x))-((-b.y)*(a.y)+(a.y*a.y))-((-b.z)*(a.z)+(a.z*a.z) );
	float totalBottom = std::sqrt( ((b.x-a.x)*(b.x-a.x))+((b.y-a.y)*(b.y-a.y))+((b.z-a.z)*(b.z-a.z)) )
						*std::sqrt( (a.x*a.x)+(a.y*a.y)+(a.z*a.z) );
	float theta = std::acos(totalTop/totalBottom);
	
	return theta;
}

bool UltraKinect::isJumping()
{
	if (isCrouching())
		return false;
	
	Skeleton skel = m_kinect->GetSkeleton();
		
	return skel.GetHead().y > m_headStartY+0.2f;
	
	return false;
}

Skeleton::Joint UltraKinect::getJointDir(Skeleton::JointTypes ja, Skeleton::JointTypes jb)
{
	Skeleton::Joint a = m_kinect->GetSkeleton().GetJointValue(ja);
	Skeleton::Joint b = m_kinect->GetSkeleton().GetJointValue(jb);
	
	Skeleton::Joint ret( subtractJoints(b, a) );
	
	float mag = std::sqrt( (ret.x*ret.x)+(ret.y*ret.y)+(ret.z*ret.z) );
	ret = multiplyJoints(ret, 1/mag);
	
	return ret;
}
