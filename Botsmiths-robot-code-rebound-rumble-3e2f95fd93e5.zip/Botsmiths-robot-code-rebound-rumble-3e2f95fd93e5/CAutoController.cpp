#include "CAutoController.h"
#include "CRobot.h"
#include <vector>

const float THRESHOLD = 0.1f;

CAutoController::CAutoController()
:IRobotController()
{
	std::cout << "Creating autonomus controller.\n";
	
	//Kinect
	/////////////////////////////////////////////////
	m_kinect.reset(new UltraKinect);
	/////////////////////////////////////////////////
	//Auto
	/////////////////////////////////////////////////
	m_ds = DriverStation::GetInstance();
	/////////////////////////////////////////////////
}

void CAutoController::update()
{
	if ( m_ds->GetDigitalIn(1) )
		updateKinect();
	else
		updateAuto();
}

void CAutoController::updateAuto()
{
	
}

bool CAutoController::updateKinect()
{
	if ( !m_kinect->isValid() )
		return false;
	
	m_kinect->update();
	
	/*
	//Driving
	///////////////////////////////////////////////////////////////////////////////////
	float leanX = m_kinect->getJointDir(Skeleton::HipCenter, Skeleton::Head).x;
	
	float lSpeed = 0.0f;
	float rSpeed = 0.0f;
	
	lSpeed = leanX*0.3f;
	rSpeed = -leanX*0.3f;
	
	if ( m_kinect->isCrouching() )
	{
		lSpeed += 0.3f;
		rSpeed += 0.3f;
	}
	else if ( m_kinect->isDownSignal(EJS_RIGHT) )
	{
		lSpeed -= 0.3f;
		rSpeed -= 0.3f;
	}
	
	m_parentBot->driveLeftMotor(lSpeed);
	m_parentBot->driveRightMotor(rSpeed);
	///////////////////////////////////////////////////////////////////////////////////
	
	//Throwing
	///////////////////////////////////////////////////////////////////////////////////
	if ( m_kinect->isUpSignal(EJS_RIGHT) )
	{
		m_parentBot->setChuteState(ECS_OPENED);
		m_parentBot->setLaunchMotor(0.6f);
		sleep(2);
		m_parentBot->setLaunchMotor(0.0f);
		m_parentBot->setChuteState(ECS_CLOSED);
	}
	///////////////////////////////////////////////////////////////////////////////////
	*/
	
	//Drive
	float lSpeed = 0.0f;
	float rSpeed = 0.0f;
	
	if ( m_kinect->isJointOnSide(EJS_RIGHT, Skeleton::HandLeft) )
	{
		lSpeed = 0.3f;
		rSpeed = -0.3f;
	}
	else if ( m_kinect->isJointOnSide(EJS_LEFT, Skeleton::HandRight) )
	{
		rSpeed = 0.3f;
		lSpeed = -0.3f;
	}
	
	if ( m_kinect->isCrouching() )
	{
		rSpeed = 0.4f;
		lSpeed = 0.4f;
	}
	
	if ( m_kinect->isUpSignal(EJS_LEFT) )
	{
		rSpeed = -0.25f;
		lSpeed = -0.25f;
	}
	
	m_parentBot->driveLeftMotor(lSpeed);
	m_parentBot->driveRightMotor(rSpeed);
	
	if ( m_kinect->isJumping() )
	{
		m_parentBot->driveLeftMotor(0.0f);
		m_parentBot->driveRightMotor(0.0f);
		
		m_parentBot->setChuteState(ECS_OPENED);
		m_parentBot->setLaunchMotor(0.6f);
		sleep(2);
		m_parentBot->setLaunchMotor(0.0f);
		m_parentBot->setChuteState(ECS_CLOSED);
		
		//m_parentBot->moveArm(0.5f);
	}
	
	return true;
}
