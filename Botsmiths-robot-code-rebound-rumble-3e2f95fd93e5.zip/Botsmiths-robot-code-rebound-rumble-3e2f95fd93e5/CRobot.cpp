#include "CRobot.h"
#include "IRobotController.h"

//Ports
const unsigned int MOTOR_ARM = 3;

const unsigned int LAUNCHER_MOTOR = 4;

const unsigned int FAN_RELAY = 2;

const unsigned int ULTRASONIC_PING_CHANNEL = 2;//out
const unsigned int ULTRASONIC_ECHO_CHANNEL = 3;//in

const unsigned int ARM_SWITCH = 4;

const unsigned int WHEEL_INPUT = 5;

CRobot::CRobot(Jaguar* left, Jaguar* right)
:m_leftMotor(left), m_rightMotor(right), m_controller(0), m_wheelRotations(0)//, m_state(ECS_CLOSED)
{
	//Piston controller
	m_pistonControl.reset(new CPistonControl());
	m_pistonControl->setPiston(false);
	
	//Arm motor
	m_armMotor.reset(new Jaguar(MOTOR_ARM));
	//Arm switch
	m_armInput.reset(new DigitalInput(ARM_SWITCH));
	
	//Fan relay
	m_fanRelay.reset(new Relay(FAN_RELAY, Relay::kForwardOnly));
	m_fanRelay->Set(Relay::kOff);
	
	//Launch motor
	m_launchMotor.reset(new Victor(LAUNCHER_MOTOR));
	
	//Ultrasonic range finder
	m_ultraSonicSensor.reset(new Ultrasonic(ULTRASONIC_PING_CHANNEL, ULTRASONIC_ECHO_CHANNEL, Ultrasonic::kMilliMeters));
	m_ultraSonicSensor->SetAutomaticMode(true);
	
	//wheel
	m_wheelInput.reset(new DigitalInput(WHEEL_INPUT));
	
	if ( !isArmOpen() )
	{
		moveArm(0.5f);
		sleep(1);
		moveArm(0.0f);
	}
}

CRobot::~CRobot()
{
	if (m_controller)
			delete m_controller;
	
	delete m_rightMotor;
	delete m_leftMotor;
}

void CRobot::enableFans(bool enable)
{
	if ( enable )
		m_fanRelay->Set(Relay::kForward);
	else
		m_fanRelay->Set(Relay::kOff);
}

void CRobot::driveLeftMotor(float speed)//-speed
{
	//std::cout << "Left motor:" << speed << "\n";
	
	/*static float curSpeed = 0.0f;
	
	if ( speed > 0.0f )
		curSpeed += 0.01f;//speed/100.0f;//Runs at 50hz, dvide by 100 to get it up to full speed in 2 seconds
	else if ( speed < 0.0f )
		curSpeed -= 0.01f;
	
	//Clamp to max
	if ( curSpeed > speed )
		curSpeed = speed;
	else if ( curSpeed < -speed )
		curSpeed = -speed;
	
	m_leftMotor->Set(-curSpeed);*/
	
	m_leftMotor->Set(-speed);
}

void CRobot::driveRightMotor(float speed)//speed
{
	//std::cout << "Right motor:" << speed << "\n";
	
	/*static float curSpeed = 0.0f;
		
	if ( speed > 0.0f )
		curSpeed += 0.01f;//speed/100.0f;//Runs at 50hz, dvide by 100 to get it up to full speed in 2 seconds
	else if ( speed < 0.0f )
		curSpeed -= 0.01f;
	
	//Clamp to max
	if ( curSpeed > speed )
		curSpeed = speed;
	else if ( curSpeed < -speed )
		curSpeed = -speed;
	
	m_rightMotor->Set(curSpeed);*/
	
	m_rightMotor->Set(speed);
}

void CRobot::moveArm(float amnt)
{	
	if ( amnt > 0.0f )
	{
		if ( isArmOpen() )
		{
			if ( m_armMotor->Get() != 0.0f )
			{
				m_armMotor->Set(0.0f);
			}
			
			return;
		}
	}
	
	m_armMotor->Set(-amnt);
}

void CRobot::setRobotController(IRobotController* controller)
{
	if (m_controller)
	{
		delete m_controller;
		m_fanRelay->Set(Relay::kOff);
	}
		
	m_controller = controller;
	
	if (m_controller)
	{
		m_fanRelay->Set(Relay::kOn);
		m_controller->m_parentBot = this;
	}
}

void CRobot::update()
{
	if ( m_controller )
	{
		m_controller->update();
	}
	
	//Count rotations
	static bool flag = true;
	if ( m_wheelInput->Get() == 0 )
	{
		if ( flag )
		{
			m_wheelRotations++;
			flag = false;
		}
	}
	else
		flag = true;
	
	m_pistonControl->update();
}

void CRobot::setChuteState(E_CHUTE_STATE state)
{
	m_state = state;
	
	if ( state == ECS_OPENED )
	{
		m_pistonControl->setPiston(true);
		
		m_launchMotor->Set(0.5f);
	}
	else
	{
		m_pistonControl->setPiston(false);
		
		m_launchMotor->Set(0.0f);
	}
}

void CRobot::setLaunchMotor(float speed)
{
	m_launchMotor->Set(speed);
}

void CRobot::resetState()
{
	m_state = ECS_CLOSED;
	
	m_launchMotor->Set(0.0f);
}

double CRobot::getDistance()
{
	return 0;//m_ultraSonicSensor->GetRangeMM();
}

bool CRobot::isArmOpen()
{
	return m_armInput->Get() == 0;
}
