#ifndef ULTRA_KINECT
#define ULTRA_KINECT
#include "WPILib.h"

enum E_JOINT_SIDE
{
	EJS_LEFT,///<Joint is on left side of body
	EJS_RIGHT///<Joint is on left side of body
};

///@brief This is a wrapper around the Kinect class that provides more advanced functionality.
class UltraKinect
{
public:
	
	UltraKinect();
	
	///@brief Updates the Kinect data
	void update();
	
	///@brief Returns false if there are no players in the Kinect's area when the robot is initialized.
	///This probably means that the Kinect is not attached.
	bool isValid();
	
	///@brief Returns the delta position (since last update step) of the passed in joint.
	///@param type The joint to check the delta position of.
	///@return Delta position of the joint.
	Skeleton::Joint getDeltaPosition(Skeleton::JointTypes type);
	
	///@brief Returns the position of the joint
	///@param type The joint to check the position of.
	Skeleton::Joint getJointPosition(Skeleton::JointTypes type);
	
	///@brief Returns true if the joint is on the passed in side.
	///@param type The type of joint that we want to check for.
	bool isJointOnSide(E_JOINT_SIDE side, Skeleton::JointTypes type);
	
	///@param side The arm (left or right) to test for.
	bool isUpSignal(E_JOINT_SIDE side);
	bool isDownSignal(E_JOINT_SIDE side);
	
	///@return True if sitting/crouching, false if otherwise.
	bool isCrouching();
	
	///@return True if jumping, false if otherwise.
	bool isJumping();
	
	///@brief Gets the direction from joint a to joint b.
	Skeleton::Joint getJointDir(Skeleton::JointTypes ja, Skeleton::JointTypes jb);
	
private:
	
	Skeleton::Joint subtractJoints(Skeleton::Joint& j, Skeleton::Joint& k);
	Skeleton::Joint multiplyJoints(Skeleton::Joint& j, float f);
	
	float getJointAngles(Skeleton::JointTypes ja, Skeleton::JointTypes jb);
	
	Kinect* m_kinect;
	
	float m_headStartY;
	
	Skeleton::Joint m_jointLastPositions[Skeleton::JointCount];
	Skeleton::Joint m_jointDeltaPositions[Skeleton::JointCount];
};

#endif
