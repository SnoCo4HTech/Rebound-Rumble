#ifndef C_AUTO_CONTROLLER_H
#define C_AUTO_CONTROLLER_H
#include "IRobotController.h"
#include "UltraKinect.h"
#include <memory>

class CAutoController : public IRobotController
{
public:
	
	CAutoController();
	
	virtual void update();
	
private:
	
	bool updateKinect();
	
	void updateAuto();
	
	//Kinect
	/////////////////////////////////////////////////
	std::auto_ptr<UltraKinect> m_kinect;
	/////////////////////////////////////////////////
	//Auto
	/////////////////////////////////////////////////
	DriverStation* m_ds;
	
	/////////////////////////////////////////////////
};

#endif
