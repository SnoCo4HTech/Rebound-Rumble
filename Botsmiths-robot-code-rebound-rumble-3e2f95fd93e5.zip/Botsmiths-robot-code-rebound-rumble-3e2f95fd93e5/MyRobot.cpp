#include "WPILib.h"
#include "CRobot.h"
#include "CTeleopController.h"
#include "CAutoController.h"

const unsigned int JOY_LEFT = 1;
const unsigned int JOY_RIGHT = 2;

const unsigned int MOTOR_LEFT = 1;
const unsigned int MOTOR_RIGHT = 2;

class RobotDemo : public IterativeRobot
{
	CRobot* m_robot;
	
	Joystick* m_leftStick;
	Joystick* m_rightStick;
	
	Jaguar* m_leftMotor;
	Jaguar* m_rightMotor;
	
public:
	
	///@brief The constructor initializes the joysticks and other interfaces.
	RobotDemo(void)
	{	
		//Init motors
		m_leftMotor = new Jaguar(MOTOR_LEFT);
		m_rightMotor = new Jaguar(MOTOR_RIGHT);
		
		//Init robot
		printf("Creating CRobot instance.\n");
		m_robot = new CRobot(m_leftMotor, m_rightMotor);
		
		//Init joysticks
		printf("Initializing joysticks.\n");
		m_leftStick = new Joystick(JOY_LEFT);
		m_rightStick = new Joystick(JOY_RIGHT);
	}
	
	~RobotDemo()
	{
		delete m_robot;
		
		delete m_leftStick;
		delete m_rightStick;
	}

	void RobotInit()
	{
		
	}
	
	void TeleopInit()
	{		
		CTeleopController* control = new CTeleopController(m_leftStick, m_rightStick);
	
		m_robot->setRobotController(control);
		m_robot->enableFans(true);
	}
	
	void AutonomousInit()
	{
		printf("Initializing auto controller.\n");
		CAutoController* control = new CAutoController();
				
		m_robot->setRobotController(control);
	}
	
	void AutonomousPeriodic()
	{
		if ( m_robot )
		{
			m_robot->update();
		}
	}
	
	void TeleopPeriodic() 
	{
		if ( m_robot )
		{
			m_robot->update();
		}
	}
	
	void TeleopDisabled()
	{
		if ( m_robot )
			m_robot->resetState();
	}
	
	void AutonomusDisabled()
	{
		if ( m_robot )
			m_robot->resetState();
	}
};

START_ROBOT_CLASS(RobotDemo);

