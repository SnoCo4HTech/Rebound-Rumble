#ifndef C_ROBOT_H
#define C_ROBOT_H
#include "WPILib.h"
#include "IRobotController.h"
#include <memory>
#include "CPistonControl.h"

enum E_CHUTE_STATE
{
	ECS_OPENED,
	ECS_CLOSED
};

//Typedef to quickly swap out the speed controller type.
typedef Victor LaunchMotor;

class CRobot
{
public:
	
	CRobot(Jaguar* left, Jaguar* right);
	~CRobot();
	
	void driveLeftMotor(float speed);
	void driveRightMotor(float speed);
	
	void moveArm(float amnt);
	
	void setChuteState(E_CHUTE_STATE state);
	
	E_CHUTE_STATE getChuteState(){return m_state;}
	
	void setRobotController(IRobotController* controller);
	
	void enableFans(bool enable);
	
	void setLaunchMotor(float speed);
	
	void update();
	
	void resetState();
	
	double getDistance();
	
	bool isArmOpen();
	
	unsigned int getWheelRotations(){return m_wheelRotations;}
	
private:
	
	Jaguar* m_leftMotor;
	Jaguar* m_rightMotor;
	std::auto_ptr<Jaguar> m_armMotor;
	
	IRobotController* m_controller;
	
	std::auto_ptr<Relay> m_fanRelay;
		
	std::auto_ptr<Ultrasonic> m_ultraSonicSensor;
	
	std::auto_ptr<LaunchMotor> m_launchMotor;
	
	std::auto_ptr<CPistonControl> m_pistonControl;
	
	std::auto_ptr<DigitalInput> m_armInput;
	
	std::auto_ptr<DigitalInput> m_wheelInput;
	
	unsigned int m_wheelRotations;
	
	E_CHUTE_STATE m_state;
};

#endif
