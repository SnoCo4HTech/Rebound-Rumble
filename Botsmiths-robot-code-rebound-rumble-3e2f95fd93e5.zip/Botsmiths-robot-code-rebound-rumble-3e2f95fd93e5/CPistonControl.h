#ifndef C_PISTON_CTRL_H
#define C_PISTON_CTR_H
#include "WPILib.h"

class CPistonControl
{
public:
	
	CPistonControl();
	
	//Sets the position to either up(true) or down(false).
	void setPiston(bool up=true);
	
	void update();
	
private:
	
	std::auto_ptr<Solenoid> m_upCtrl;
	std::auto_ptr<Solenoid> m_downCtrl;
	
	std::auto_ptr<Relay> m_compressor;
	std::auto_ptr<DigitalInput> m_compressorInput;
};

#endif
